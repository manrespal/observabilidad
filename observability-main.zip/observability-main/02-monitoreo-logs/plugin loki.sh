# descargar plugin
docker plugin install grafana/loki-docker-driver:latest --alias loki --grant-all-permissions